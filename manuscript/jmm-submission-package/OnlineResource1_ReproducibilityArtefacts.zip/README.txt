Supplementary information for Journal of Molecular Modeling

Article title: A provenance-aware workflow for strict receptor-preparation audits and reference-pose recovery in molecular docking
Authors: Andrés Monreal Hernández; Sara Lizbeth Franco Amaya; Carlos Ivanhoe Martínez Osorio
Affiliation: Universidad Estatal de Sonora / Universidad de Sonora, Hermosillo, Sonora, Mexico
Corresponding author: andres.monreal@ues.mx

Contents: non-coordinate derived tables, protocols, deterministic rendering scripts, and verification material supporting the manuscript.
Excluded material: third-party coordinate files and local PDBQT/log outputs are not redistributed. Source identifiers, URLs, and checksums are retained in the included records and public repository.

Use: extract this archive and consult the repository README and validation documentation. The archive is submitted for peer-review support; its versioned public archive DOI must be inserted into the manuscript before final submission.
